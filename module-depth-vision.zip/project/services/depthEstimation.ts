interface DepthEstimationResponse {
  depth_map: string; // base64 encoded depth map
  success: boolean;
  error?: string;
}

interface DepthEstimationRequest {
  image: string; // base64 encoded image
  function_name: string;
}

export class DepthEstimationService {
  private static readonly API_URL = "https://api.va.landing.ai/v1/tools/depth-anything-v2";
  private static readonly API_KEY = process.env.EXPO_PUBLIC_DEPTH_API_KEY || "";

  static async estimateDepth(imageBase64: string): Promise<DepthEstimationResponse> {
    try {
      const payload: DepthEstimationRequest = {
        image: imageBase64,
        function_name: "depth_anything_v2"
      };

      const headers = {
        "Content-Type": "application/json",
        "Accept": "application/json",
        "Authorization": `Basic ${this.API_KEY}`
      };

      const response = await fetch(this.API_URL, {
        method: 'POST',
        headers,
        body: JSON.stringify(payload)
      });

      if (!response.ok) {
        throw new Error(`API request failed: ${response.status} ${response.statusText}`);
      }

      const data = await response.json();
      
      return {
        depth_map: data.depth_map || data.result?.depth_map,
        success: true
      };
    } catch (error) {
      console.error('Depth estimation error:', error);
      return {
        depth_map: '',
        success: false,
        error: error instanceof Error ? error.message : 'Unknown error occurred'
      };
    }
  }

  static async processImageFromUri(imageUri: string): Promise<DepthEstimationResponse> {
    try {
      // Convert image URI to base64
      const response = await fetch(imageUri);
      const blob = await response.blob();
      
      return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onloadend = () => {
          const base64String = (reader.result as string).split(',')[1];
          this.estimateDepth(base64String).then(resolve).catch(reject);
        };
        reader.onerror = reject;
        reader.readAsDataURL(blob);
      });
    } catch (error) {
      return {
        depth_map: '',
        success: false,
        error: error instanceof Error ? error.message : 'Failed to process image'
      };
    }
  }

  static convertDepthMapToVisualization(depthMapBase64: string): number[][] {
    try {
      // This would typically involve decoding the base64 image and converting to depth values
      // For now, we'll create a mock implementation that generates realistic depth data
      const rows = 40;
      const cols = 30;
      const data: number[][] = [];
      
      for (let i = 0; i < rows; i++) {
        const row: number[] = [];
        for (let j = 0; j < cols; j++) {
          // Create a more realistic depth pattern based on typical scene structure
          const centerX = cols / 2;
          const centerY = rows / 2;
          const distance = Math.sqrt((i - centerY) ** 2 + (j - centerX) ** 2);
          const maxDistance = Math.sqrt(centerY ** 2 + centerX ** 2);
          
          // Add some noise and variation for realism
          const baseDepth = 1 - (distance / maxDistance);
          const noise = (Math.random() - 0.5) * 0.2;
          const depth = Math.max(0, Math.min(1, baseDepth + noise));
          
          row.push(depth);
        }
        data.push(row);
      }
      
      return data;
    } catch (error) {
      console.error('Error converting depth map:', error);
      return [];
    }
  }
}