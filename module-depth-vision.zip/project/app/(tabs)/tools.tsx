import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  SafeAreaView,
  TextInput,
  Alert,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ruler, Calculator, Palette, Grid2x2 as Grid, Zap, Download, Upload, Settings, Target, Eye, Image as ImageIcon, CircleAlert as AlertCircle } from 'lucide-react-native';
import { DepthEstimationService } from '@/services/depthEstimation';
import { ImageCaptureService } from '@/utils/imageCapture';
import * as ImagePicker from 'expo-image-picker';

interface ToolCardProps {
  title: string;
  description: string;
  icon: React.ReactNode;
  onPress: () => void;
  isActive?: boolean;
}

const ToolCard: React.FC<ToolCardProps> = ({
  title,
  description,
  icon,
  onPress,
  isActive = false,
}) => (
  <TouchableOpacity
    style={[styles.toolCard, isActive && styles.toolCardActive]}
    onPress={onPress}
  >
    <LinearGradient
      colors={
        isActive
          ? ['#00D4FF', '#0EA5E9']
          : ['rgba(255, 255, 255, 0.05)', 'rgba(255, 255, 255, 0.02)']
      }
      style={styles.toolGradient}
    >
      <View style={styles.toolIcon}>
        {icon}
      </View>
      <Text style={[styles.toolTitle, isActive && styles.toolTitleActive]}>
        {title}
      </Text>
      <Text
        style={[styles.toolDescription, isActive && styles.toolDescriptionActive]}
      >
        {description}
      </Text>
    </LinearGradient>
  </TouchableOpacity>
);

export default function ToolsScreen() {
  const [activeTool, setActiveTool] = useState<string | null>(null);
  const [measurementValue, setMeasurementValue] = useState('');
  const [calibrationDistance, setCalibrationDistance] = useState('1.0');
  const [isProcessing, setIsProcessing] = useState(false);
  const [processingStatus, setProcessingStatus] = useState('');
  const [error, setError] = useState<string | null>(null);

  const handleImageUpload = async () => {
    try {
      setError(null);
      setIsProcessing(true);
      setProcessingStatus('Selecting image...');

      // Request permission to access media library
      const permissionResult = await ImagePicker.requestMediaLibraryPermissionsAsync();
      
      if (permissionResult.granted === false) {
        throw new Error('Permission to access camera roll is required!');
      }

      // Pick an image
      const result = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: ImagePicker.MediaTypeOptions.Images,
        allowsEditing: true,
        aspect: [4, 3],
        quality: 0.8,
        base64: true,
      });

      if (result.canceled) {
        setIsProcessing(false);
        return;
      }

      const selectedImage = result.assets[0];
      
      if (!selectedImage.base64) {
        throw new Error('Failed to convert image to base64');
      }

      setProcessingStatus('Analyzing depth...');

      // Call depth estimation API
      const depthResult = await DepthEstimationService.estimateDepth(selectedImage.base64);
      
      if (!depthResult.success) {
        throw new Error(depthResult.error || 'Depth estimation failed');
      }

      setProcessingStatus('Processing complete!');
      
      // Show success message
      Alert.alert(
        'Depth Analysis Complete',
        'The image has been successfully processed for depth estimation.',
        [{ text: 'OK' }]
      );

    } catch (error) {
      console.error('Image upload and processing error:', error);
      setError(error instanceof Error ? error.message : 'An unknown error occurred');
    } finally {
      setIsProcessing(false);
      setProcessingStatus('');
    }
  };

  const handleBatchProcessing = async () => {
    try {
      setError(null);
      setIsProcessing(true);
      setProcessingStatus('Starting batch processing...');

      // Request permission to access media library
      const permissionResult = await ImagePicker.requestMediaLibraryPermissionsAsync();
      
      if (permissionResult.granted === false) {
        throw new Error('Permission to access camera roll is required!');
      }

      // Pick multiple images
      const result = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: ImagePicker.MediaTypeOptions.Images,
        allowsMultipleSelection: true,
        quality: 0.8,
        base64: true,
      });

      if (result.canceled) {
        setIsProcessing(false);
        return;
      }

      const images = result.assets;
      let processedCount = 0;

      for (const image of images) {
        setProcessingStatus(`Processing image ${processedCount + 1} of ${images.length}...`);
        
        if (image.base64) {
          const depthResult = await DepthEstimationService.estimateDepth(image.base64);
          
          if (depthResult.success) {
            processedCount++;
          }
        }
      }

      setProcessingStatus('Batch processing complete!');
      
      Alert.alert(
        'Batch Processing Complete',
        `Successfully processed ${processedCount} out of ${images.length} images.`,
        [{ text: 'OK' }]
      );

    } catch (error) {
      console.error('Batch processing error:', error);
      setError(error instanceof Error ? error.message : 'Batch processing failed');
    } finally {
      setIsProcessing(false);
      setProcessingStatus('');
    }
  };

  const tools = [
    {
      title: 'Measurement Tool',
      description: 'Measure real-world distances using depth data',
      icon: <Ruler size={24} color={activeTool === 'measurement' ? '#FFFFFF' : '#00D4FF'} />,
      id: 'measurement',
    },
    {
      title: 'Depth Calculator',
      description: 'Advanced calculations and depth analysis',
      icon: <Calculator size={24} color={activeTool === 'calculator' ? '#FFFFFF' : '#00D4FF'} />,
      id: 'calculator',
    },
    {
      title: 'Image Upload',
      description: 'Upload images for depth estimation analysis',
      icon: <ImageIcon size={24} color={activeTool === 'upload' ? '#FFFFFF' : '#00D4FF'} />,
      id: 'upload',
    },
    {
      title: 'Color Mapping',
      description: 'Customize depth visualization colors',
      icon: <Palette size={24} color={activeTool === 'colormapping' ? '#FFFFFF' : '#00D4FF'} />,
      id: 'colormapping',
    },
    {
      title: 'Grid Overlay',
      description: 'Add measurement grids to your view',
      icon: <Grid size={24} color={activeTool === 'grid' ? '#FFFFFF' : '#00D4FF'} />,
      id: 'grid',
    },
    {
      title: 'Calibration',
      description: 'Camera and sensor calibration tools',
      icon: <Target size={24} color={activeTool === 'calibration' ? '#FFFFFF' : '#00D4FF'} />,
      id: 'calibration',
    },
  ];

  const renderToolContent = () => {
    switch (activeTool) {
      case 'upload':
        return (
          <View style={styles.toolContent}>
            <Text style={styles.contentTitle}>Image Upload & Analysis</Text>
            <Text style={styles.contentDescription}>
              Upload images from your gallery to analyze depth using AI-powered estimation.
            </Text>
            
            {error && (
              <View style={styles.errorContainer}>
                <AlertCircle size={16} color="#FF6B6B" />
                <Text style={styles.errorText}>{error}</Text>
              </View>
            )}
            
            {isProcessing && (
              <View style={styles.processingContainer}>
                <Zap size={20} color="#00D4FF" />
                <Text style={styles.processingText}>{processingStatus}</Text>
              </View>
            )}
            
            <View style={styles.uploadActions}>
              <TouchableOpacity 
                style={[styles.actionButton, isProcessing && styles.actionButtonDisabled]}
                onPress={handleImageUpload}
                disabled={isProcessing}
              >
                <Upload size={16} color="#FFFFFF" />
                <Text style={styles.actionButtonText}>Upload Single Image</Text>
              </TouchableOpacity>
              
              <TouchableOpacity 
                style={[styles.actionButton, isProcessing && styles.actionButtonDisabled]}
                onPress={handleBatchProcessing}
                disabled={isProcessing}
              >
                <Upload size={16} color="#FFFFFF" />
                <Text style={styles.actionButtonText}>Batch Process</Text>
              </TouchableOpacity>
            </View>
          </View>
        );

      case 'measurement':
        return (
          <View style={styles.toolContent}>
            <Text style={styles.contentTitle}>Measurement Tool</Text>
            <Text style={styles.contentDescription}>
              Tap two points on the depth view to measure the distance between them.
            </Text>
            <View style={styles.inputGroup}>
              <Text style={styles.inputLabel}>Current Measurement</Text>
              <TextInput
                style={styles.input}
                value={measurementValue}
                onChangeText={setMeasurementValue}
                placeholder="0.00 meters"
                placeholderTextColor="#6B7280"
              />
            </View>
            <TouchableOpacity style={styles.actionButton}>
              <Zap size={16} color="#FFFFFF" />
              <Text style={styles.actionButtonText}>Start Measuring</Text>
            </TouchableOpacity>
          </View>
        );

      case 'calibration':
        return (
          <View style={styles.toolContent}>
            <Text style={styles.contentTitle}>Camera Calibration</Text>
            <Text style={styles.contentDescription}>
              Place a known object at a specific distance to calibrate depth accuracy.
            </Text>
            <View style={styles.inputGroup}>
              <Text style={styles.inputLabel}>Reference Distance (meters)</Text>
              <TextInput
                style={styles.input}
                value={calibrationDistance}
                onChangeText={setCalibrationDistance}
                placeholder="1.0"
                placeholderTextColor="#6B7280"
                keyboardType="numeric"
              />
            </View>
            <TouchableOpacity style={styles.actionButton}>
              <Target size={16} color="#FFFFFF" />
              <Text style={styles.actionButtonText}>Calibrate</Text>
            </TouchableOpacity>
          </View>
        );

      case 'colormapping':
        return (
          <View style={styles.toolContent}>
            <Text style={styles.contentTitle}>Color Mapping</Text>
            <Text style={styles.contentDescription}>
              Choose how depth information is visualized with different color schemes.
            </Text>
            <View style={styles.colorOptions}>
              {['Thermal', 'Rainbow', 'Grayscale', 'Ocean', 'Viridis'].map((scheme) => (
                <TouchableOpacity key={scheme} style={styles.colorOption}>
                  <View style={[styles.colorSwatch, { backgroundColor: getColorForScheme(scheme) }]} />
                  <Text style={styles.colorOptionText}>{scheme}</Text>
                </TouchableOpacity>
              ))}
            </View>
          </View>
        );

      default:
        return (
          <View style={styles.toolContent}>
            <Text style={styles.contentTitle}>Select a Tool</Text>
            <Text style={styles.contentDescription}>
              Choose from the tools above to access advanced depth estimation features.
            </Text>
          </View>
        );
    }
  };

  return (
    <View style={styles.container}>
      <LinearGradient
        colors={['#1F2937', '#111827']}
        style={styles.gradient}
      >
        <SafeAreaView style={styles.safeArea}>
          <View style={styles.header}>
            <Text style={styles.title}>Tools & Utilities</Text>
            <Text style={styles.subtitle}>
              Advanced features for depth analysis
            </Text>
          </View>

          <ScrollView
            style={styles.scrollView}
            showsVerticalScrollIndicator={false}
          >
            <View style={styles.toolsGrid}>
              {tools.map((tool) => (
                <ToolCard
                  key={tool.id}
                  title={tool.title}
                  description={tool.description}
                  icon={tool.icon}
                  isActive={activeTool === tool.id}
                  onPress={() => setActiveTool(activeTool === tool.id ? null : tool.id)}
                />
              ))}
            </View>

            <View style={styles.contentSection}>
              {renderToolContent()}
            </View>
          </ScrollView>
        </SafeAreaView>
      </LinearGradient>
    </View>
  );
}

function getColorForScheme(scheme: string): string {
  const colors = {
    Thermal: '#FF6B6B',
    Rainbow: '#FF8E53',
    Grayscale: '#9CA3AF',
    Ocean: '#0EA5E9',
    Viridis: '#8B5CF6',
  };
  return colors[scheme as keyof typeof colors] || '#00D4FF';
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  gradient: {
    flex: 1,
  },
  safeArea: {
    flex: 1,
  },
  header: {
    padding: 20,
    paddingBottom: 10,
  },
  title: {
    fontSize: 28,
    fontFamily: 'Inter-Bold',
    color: '#FFFFFF',
    marginBottom: 8,
  },
  subtitle: {
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    color: '#9CA3AF',
  },
  scrollView: {
    flex: 1,
    paddingHorizontal: 20,
  },
  toolsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
    marginBottom: 20,
  },
  toolCard: {
    width: '48%',
    borderRadius: 12,
    overflow: 'hidden',
  },
  toolCardActive: {
    transform: [{ scale: 1.02 }],
  },
  toolGradient: {
    padding: 16,
    alignItems: 'center',
  },
  toolIcon: {
    marginBottom: 12,
  },
  toolTitle: {
    fontSize: 14,
    fontFamily: 'Inter-Bold',
    color: '#FFFFFF',
    textAlign: 'center',
    marginBottom: 8,
  },
  toolTitleActive: {
    color: '#FFFFFF',
  },
  toolDescription: {
    fontSize: 12,
    fontFamily: 'Inter-Regular',
    color: '#9CA3AF',
    textAlign: 'center',
    lineHeight: 16,
  },
  toolDescriptionActive: {
    color: 'rgba(255, 255, 255, 0.9)',
  },
  contentSection: {
    backgroundColor: 'rgba(255, 255, 255, 0.05)',
    borderRadius: 16,
    padding: 20,
    marginBottom: 20,
  },
  toolContent: {
    alignItems: 'center',
  },
  contentTitle: {
    fontSize: 20,
    fontFamily: 'Inter-Bold',
    color: '#FFFFFF',
    marginBottom: 8,
  },
  contentDescription: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#9CA3AF',
    textAlign: 'center',
    marginBottom: 20,
    lineHeight: 20,
  },
  errorContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(255, 107, 107, 0.1)',
    padding: 12,
    borderRadius: 8,
    marginBottom: 16,
    gap: 8,
  },
  errorText: {
    flex: 1,
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#FF6B6B',
  },
  processingContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(0, 212, 255, 0.1)',
    padding: 12,
    borderRadius: 8,
    marginBottom: 16,
    gap: 8,
  },
  processingText: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#00D4FF',
  },
  uploadActions: {
    width: '100%',
    gap: 12,
  },
  inputGroup: {
    width: '100%',
    marginBottom: 20,
  },
  inputLabel: {
    fontSize: 14,
    fontFamily: 'Inter-SemiBold',
    color: '#FFFFFF',
    marginBottom: 8,
  },
  input: {
    width: '100%',
    height: 48,
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    borderRadius: 8,
    paddingHorizontal: 16,
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    color: '#FFFFFF',
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.2)',
  },
  actionButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#00D4FF',
    paddingHorizontal: 24,
    paddingVertical: 12,
    borderRadius: 8,
    gap: 8,
  },
  actionButtonDisabled: {
    backgroundColor: '#6B7280',
    opacity: 0.6,
  },
  actionButtonText: {
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
    color: '#FFFFFF',
  },
  colorOptions: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
    justifyContent: 'center',
  },
  colorOption: {
    alignItems: 'center',
    gap: 8,
  },
  colorSwatch: {
    width: 40,
    height: 40,
    borderRadius: 20,
    borderWidth: 2,
    borderColor: 'rgba(255, 255, 255, 0.3)',
  },
  colorOptionText: {
    fontSize: 12,
    fontFamily: 'Inter-Regular',
    color: '#9CA3AF',
  },
});