import React, { useState, useRef, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Dimensions,
  SafeAreaView,
  Platform,
  Alert,
} from 'react-native';
import { CameraView, CameraType, useCameraPermissions } from 'expo-camera';
import { LinearGradient } from 'expo-linear-gradient';
import { BlurView } from 'expo-blur';
import { Camera, RotateCcw, Zap, Maximize, Download, Play, Pause, CircleAlert as AlertCircle } from 'lucide-react-native';
import { StatusInfo } from '@/components/StatusInfo';
import { DepthVisualization } from '@/components/DepthVisualization';
import { DepthEstimationService } from '@/services/depthEstimation';
import { ImageCaptureService, CapturedImage } from '@/utils/imageCapture';

const { width: screenWidth, height: screenHeight } = Dimensions.get('window');

export default function CaptureScreen() {
  const [facing, setFacing] = useState<CameraType>('back');
  const [permission, requestPermission] = useCameraPermissions();
  const [isCapturing, setIsCapturing] = useState(false);
  const [currentMethod, setCurrentMethod] = useState('RGB');
  const [depthData, setDepthData] = useState<number[][]>([]);
  const [isProcessing, setIsProcessing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [lastCapturedImage, setLastCapturedImage] = useState<CapturedImage | null>(null);
  
  const cameraRef = useRef<CameraView>(null);

  const handleCapture = async () => {
    if (isCapturing || isProcessing) return;
    
    setIsCapturing(true);
    setIsProcessing(true);
    setError(null);
    
    try {
      // Capture photo from camera
      const capturedImage = await ImageCaptureService.capturePhoto(cameraRef);
      
      if (!capturedImage) {
        throw new Error('Failed to capture image');
      }

      setLastCapturedImage(capturedImage);

      // Convert to base64 if not already available
      let base64Image = capturedImage.base64;
      if (!base64Image) {
        base64Image = await ImageCaptureService.convertUriToBase64(capturedImage.uri);
      }

      if (!base64Image) {
        throw new Error('Failed to convert image to base64');
      }

      // Call depth estimation API
      const depthResult = await DepthEstimationService.estimateDepth(base64Image);
      
      if (!depthResult.success) {
        throw new Error(depthResult.error || 'Depth estimation failed');
      }

      // Convert depth map to visualization data
      const visualizationData = DepthEstimationService.convertDepthMapToVisualization(
        depthResult.depth_map
      );
      
      setDepthData(visualizationData);
      
    } catch (error) {
      console.error('Capture and depth estimation error:', error);
      setError(error instanceof Error ? error.message : 'An unknown error occurred');
      
      // Fallback to mock data for demonstration
      const mockData = generateMockDepthData();
      setDepthData(mockData);
    } finally {
      setIsProcessing(false);
      setIsCapturing(false);
    }
  };

  // Mock depth estimation for demonstration when API fails
  const generateMockDepthData = () => {
    const data: number[][] = [];
    const rows = 40;
    const cols = 30;
    
    for (let i = 0; i < rows; i++) {
      const row: number[] = [];
      for (let j = 0; j < cols; j++) {
        const centerX = cols / 2;
        const centerY = rows / 2;
        const distance = Math.sqrt((i - centerY) ** 2 + (j - centerX) ** 2);
        const maxDistance = Math.sqrt(centerY ** 2 + centerX ** 2);
        const depth = 1 - (distance / maxDistance);
        row.push(depth);
      }
      data.push(row);
    }
    return data;
  };

  const toggleCameraFacing = () => {
    setFacing(current => (current === 'back' ? 'front' : 'back'));
  };

  const clearError = () => {
    setError(null);
  };

  if (!permission) {
    return <View style={styles.container} />;
  }

  if (!permission.granted) {
    return (
      <View style={styles.permissionContainer}>
        <LinearGradient
          colors={['#1F2937', '#111827']}
          style={styles.gradient}
        >
          <View style={styles.permissionContent}>
            <Camera size={64} color="#00D4FF" />
            <Text style={styles.permissionTitle}>Camera Access Required</Text>
            <Text style={styles.permissionText}>
              We need camera access to perform depth estimation
            </Text>
            <TouchableOpacity
              style={styles.permissionButton}
              onPress={requestPermission}
            >
              <Text style={styles.permissionButtonText}>Grant Permission</Text>
            </TouchableOpacity>
          </View>
        </LinearGradient>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <LinearGradient
        colors={['#1F2937', '#111827']}
        style={styles.gradient}
      >
        <SafeAreaView style={styles.safeArea}>
          <StatusInfo currentMethod={currentMethod} />
          
          {error && (
            <View style={styles.errorContainer}>
              <BlurView intensity={20} style={styles.errorBlur}>
                <View style={styles.errorContent}>
                  <AlertCircle size={20} color="#FF6B6B" />
                  <Text style={styles.errorText}>{error}</Text>
                  <TouchableOpacity onPress={clearError} style={styles.errorDismiss}>
                    <Text style={styles.errorDismissText}>Dismiss</Text>
                  </TouchableOpacity>
                </View>
              </BlurView>
            </View>
          )}
          
          <View style={styles.cameraContainer}>
            <View style={styles.cameraWrapper}>
              <CameraView 
                ref={cameraRef}
                style={styles.camera} 
                facing={facing}
              >
                <View style={styles.overlay}>
                  <View style={styles.crosshair}>
                    <View style={styles.crosshairLine} />
                    <View style={[styles.crosshairLine, styles.crosshairLineVertical]} />
                  </View>
                </View>
              </CameraView>
              
              {depthData.length > 0 && (
                <View style={styles.depthOverlay}>
                  <DepthVisualization depthData={depthData} />
                </View>
              )}
              
              {isProcessing && (
                <BlurView intensity={20} style={styles.processingOverlay}>
                  <View style={styles.processingContent}>
                    <Zap size={32} color="#00D4FF" />
                    <Text style={styles.processingText}>
                      {currentMethod === 'RGB' ? 'Processing RGB Depth...' : 'Processing Depth...'}
                    </Text>
                    <Text style={styles.processingSubtext}>
                      Using AI-powered depth estimation
                    </Text>
                  </View>
                </BlurView>
              )}
            </View>
          </View>

          <View style={styles.controls}>
            <View style={styles.controlRow}>
              <TouchableOpacity
                style={styles.controlButton}
                onPress={toggleCameraFacing}
              >
                <RotateCcw size={24} color="#FFFFFF" />
              </TouchableOpacity>

              <TouchableOpacity
                style={[styles.captureButton, isCapturing && styles.captureButtonActive]}
                onPress={handleCapture}
                disabled={isCapturing || isProcessing}
              >
                <LinearGradient
                  colors={isCapturing ? ['#FF6B6B', '#FF8E8E'] : ['#00D4FF', '#0EA5E9']}
                  style={styles.captureGradient}
                >
                  {isCapturing ? (
                    <Pause size={32} color="#FFFFFF" />
                  ) : (
                    <Play size={32} color="#FFFFFF" />
                  )}
                </LinearGradient>
              </TouchableOpacity>

              <TouchableOpacity
                style={styles.controlButton}
                onPress={() => {
                  if (lastCapturedImage) {
                    // Handle download/save functionality
                    console.log('Saving image:', lastCapturedImage.uri);
                  }
                }}
              >
                <Download size={24} color="#FFFFFF" />
              </TouchableOpacity>
            </View>

            <View style={styles.methodSelector}>
              {['RGB', 'LiDAR', 'Stereo'].map((method) => (
                <TouchableOpacity
                  key={method}
                  style={[
                    styles.methodButton,
                    currentMethod === method && styles.methodButtonActive
                  ]}
                  onPress={() => setCurrentMethod(method)}
                >
                  <Text
                    style={[
                      styles.methodButtonText,
                      currentMethod === method && styles.methodButtonTextActive
                    ]}
                  >
                    {method}
                  </Text>
                </TouchableOpacity>
              ))}
            </View>
          </View>
        </SafeAreaView>
      </LinearGradient>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  gradient: {
    flex: 1,
  },
  safeArea: {
    flex: 1,
  },
  permissionContainer: {
    flex: 1,
  },
  permissionContent: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  permissionTitle: {
    fontSize: 24,
    fontFamily: 'Inter-Bold',
    color: '#FFFFFF',
    marginTop: 20,
    marginBottom: 10,
  },
  permissionText: {
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    color: '#9CA3AF',
    textAlign: 'center',
    marginBottom: 30,
  },
  permissionButton: {
    backgroundColor: '#00D4FF',
    paddingHorizontal: 30,
    paddingVertical: 15,
    borderRadius: 25,
  },
  permissionButtonText: {
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
    color: '#FFFFFF',
  },
  errorContainer: {
    position: 'absolute',
    top: 100,
    left: 20,
    right: 20,
    zIndex: 1000,
    borderRadius: 12,
    overflow: 'hidden',
  },
  errorBlur: {
    padding: 16,
  },
  errorContent: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  errorText: {
    flex: 1,
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#FFFFFF',
  },
  errorDismiss: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    borderRadius: 6,
  },
  errorDismissText: {
    fontSize: 12,
    fontFamily: 'Inter-SemiBold',
    color: '#FFFFFF',
  },
  cameraContainer: {
    flex: 1,
    marginHorizontal: 20,
    marginTop: 20,
  },
  cameraWrapper: {
    flex: 1,
    borderRadius: 20,
    overflow: 'hidden',
    position: 'relative',
  },
  camera: {
    flex: 1,
  },
  overlay: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    justifyContent: 'center',
    alignItems: 'center',
  },
  crosshair: {
    position: 'relative',
  },
  crosshairLine: {
    position: 'absolute',
    backgroundColor: '#00D4FF',
    opacity: 0.8,
    width: 40,
    height: 2,
    left: -20,
  },
  crosshairLineVertical: {
    width: 2,
    height: 40,
    left: -1,
    top: -20,
  },
  depthOverlay: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    opacity: 0.7,
  },
  processingOverlay: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    justifyContent: 'center',
    alignItems: 'center',
  },
  processingContent: {
    alignItems: 'center',
  },
  processingText: {
    fontSize: 18,
    fontFamily: 'Inter-SemiBold',
    color: '#FFFFFF',
    marginTop: 10,
  },
  processingSubtext: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#9CA3AF',
    marginTop: 4,
  },
  controls: {
    padding: 20,
  },
  controlRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 20,
  },
  controlButton: {
    width: 50,
    height: 50,
    borderRadius: 25,
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  captureButton: {
    width: 80,
    height: 80,
    borderRadius: 40,
    overflow: 'hidden',
  },
  captureButtonActive: {
    transform: [{ scale: 0.95 }],
  },
  captureGradient: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  methodSelector: {
    flexDirection: 'row',
    justifyContent: 'center',
    gap: 10,
  },
  methodButton: {
    paddingHorizontal: 20,
    paddingVertical: 10,
    borderRadius: 20,
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.2)',
  },
  methodButtonActive: {
    backgroundColor: '#00D4FF',
    borderColor: '#00D4FF',
  },
  methodButtonText: {
    fontSize: 14,
    fontFamily: 'Inter-SemiBold',
    color: '#9CA3AF',
  },
  methodButtonTextActive: {
    color: '#FFFFFF',
  },
});