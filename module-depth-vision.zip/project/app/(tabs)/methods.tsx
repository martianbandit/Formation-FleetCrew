import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  SafeAreaView,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import {
  Camera,
  Radar,
  Triangle,
  Cpu,
  Eye,
  Zap,
  Settings,
  Info,
} from 'lucide-react-native';

interface MethodCardProps {
  title: string;
  description: string;
  icon: React.ReactNode;
  accuracy: number;
  speed: number;
  isActive: boolean;
  onPress: () => void;
}

const MethodCard: React.FC<MethodCardProps> = ({
  title,
  description,
  icon,
  accuracy,
  speed,
  isActive,
  onPress,
}) => (
  <TouchableOpacity
    style={[styles.methodCard, isActive && styles.methodCardActive]}
    onPress={onPress}
  >
    <LinearGradient
      colors={isActive ? ['#00D4FF', '#0EA5E9'] : ['rgba(255, 255, 255, 0.05)', 'rgba(255, 255, 255, 0.02)']}
      style={styles.cardGradient}
    >
      <View style={styles.cardHeader}>
        <View style={styles.cardIcon}>
          {icon}
        </View>
        <Text style={[styles.cardTitle, isActive && styles.cardTitleActive]}>
          {title}
        </Text>
      </View>
      
      <Text style={[styles.cardDescription, isActive && styles.cardDescriptionActive]}>
        {description}
      </Text>
      
      <View style={styles.cardMetrics}>
        <View style={styles.metric}>
          <Text style={[styles.metricLabel, isActive && styles.metricLabelActive]}>
            Accuracy
          </Text>
          <View style={styles.progressBar}>
            <View
              style={[
                styles.progressFill,
                { width: `${accuracy}%` },
                isActive && styles.progressFillActive,
              ]}
            />
          </View>
          <Text style={[styles.metricValue, isActive && styles.metricValueActive]}>
            {accuracy}%
          </Text>
        </View>
        
        <View style={styles.metric}>
          <Text style={[styles.metricLabel, isActive && styles.metricLabelActive]}>
            Speed
          </Text>
          <View style={styles.progressBar}>
            <View
              style={[
                styles.progressFill,
                { width: `${speed}%` },
                isActive && styles.progressFillActive,
              ]}
            />
          </View>
          <Text style={[styles.metricValue, isActive && styles.metricValueActive]}>
            {speed}%
          </Text>
        </View>
      </View>
    </LinearGradient>
  </TouchableOpacity>
);

export default function MethodsScreen() {
  const [activeMethod, setActiveMethod] = useState('RGB Monocular');

  const methods = [
    {
      title: 'RGB Monocular',
      description: 'Single camera depth estimation using neural networks and computer vision algorithms.',
      icon: <Camera size={24} color={activeMethod === 'RGB Monocular' ? '#FFFFFF' : '#00D4FF'} />,
      accuracy: 75,
      speed: 90,
    },
    {
      title: 'LiDAR Fusion',
      description: 'Precision depth mapping using Light Detection and Ranging technology.',
      icon: <Radar size={24} color={activeMethod === 'LiDAR Fusion' ? '#FFFFFF' : '#00D4FF'} />,
      accuracy: 95,
      speed: 80,
    },
    {
      title: 'Stereo Vision',
      description: 'Dual camera triangulation for accurate depth calculation.',
      icon: <Triangle size={24} color={activeMethod === 'Stereo Vision' ? '#FFFFFF' : '#00D4FF'} />,
      accuracy: 85,
      speed: 70,
    },
    {
      title: 'AI Enhanced',
      description: 'Machine learning models trained on massive depth datasets.',
      icon: <Cpu size={24} color={activeMethod === 'AI Enhanced' ? '#FFFFFF' : '#00D4FF'} />,
      accuracy: 88,
      speed: 85,
    },
    {
      title: 'Structured Light',
      description: 'Projected pattern analysis for indoor depth sensing.',
      icon: <Eye size={24} color={activeMethod === 'Structured Light' ? '#FFFFFF' : '#00D4FF'} />,
      accuracy: 92,
      speed: 75,
    },
  ];

  return (
    <View style={styles.container}>
      <LinearGradient
        colors={['#1F2937', '#111827']}
        style={styles.gradient}
      >
        <SafeAreaView style={styles.safeArea}>
          <View style={styles.header}>
            <Text style={styles.title}>Depth Methods</Text>
            <Text style={styles.subtitle}>
              Choose your preferred depth estimation technique
            </Text>
          </View>

          <ScrollView
            style={styles.scrollView}
            showsVerticalScrollIndicator={false}
          >
            {methods.map((method) => (
              <MethodCard
                key={method.title}
                title={method.title}
                description={method.description}
                icon={method.icon}
                accuracy={method.accuracy}
                speed={method.speed}
                isActive={activeMethod === method.title}
                onPress={() => setActiveMethod(method.title)}
              />
            ))}

            <View style={styles.infoSection}>
              <View style={styles.infoHeader}>
                <Info size={20} color="#00D4FF" />
                <Text style={styles.infoTitle}>Method Selection Tips</Text>
              </View>
              <Text style={styles.infoText}>
                • RGB Monocular: Best for general use with single camera{'\n'}
                • LiDAR: Highest accuracy for supported devices{'\n'}
                • Stereo Vision: Great for outdoor scenes{'\n'}
                • AI Enhanced: Balanced performance across scenarios{'\n'}
                • Structured Light: Optimal for indoor measurements
              </Text>
            </View>
          </ScrollView>

          <View style={styles.bottomActions}>
            <TouchableOpacity style={styles.actionButton}>
              <Settings size={20} color="#FFFFFF" />
              <Text style={styles.actionButtonText}>Configure</Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.primaryActionButton}>
              <LinearGradient
                colors={['#00D4FF', '#0EA5E9']}
                style={styles.primaryActionGradient}
              >
                <Zap size={20} color="#FFFFFF" />
                <Text style={styles.primaryActionButtonText}>Apply Method</Text>
              </LinearGradient>
            </TouchableOpacity>
          </View>
        </SafeAreaView>
      </LinearGradient>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  gradient: {
    flex: 1,
  },
  safeArea: {
    flex: 1,
  },
  header: {
    padding: 20,
    paddingBottom: 10,
  },
  title: {
    fontSize: 28,
    fontFamily: 'Inter-Bold',
    color: '#FFFFFF',
    marginBottom: 8,
  },
  subtitle: {
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    color: '#9CA3AF',
  },
  scrollView: {
    flex: 1,
    paddingHorizontal: 20,
  },
  methodCard: {
    marginBottom: 16,
    borderRadius: 16,
    overflow: 'hidden',
  },
  methodCardActive: {
    transform: [{ scale: 1.02 }],
  },
  cardGradient: {
    padding: 20,
  },
  cardHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
  },
  cardIcon: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(0, 212, 255, 0.2)',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
  },
  cardTitle: {
    fontSize: 18,
    fontFamily: 'Inter-Bold',
    color: '#FFFFFF',
    flex: 1,
  },
  cardTitleActive: {
    color: '#FFFFFF',
  },
  cardDescription: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#9CA3AF',
    marginBottom: 16,
    lineHeight: 20,
  },
  cardDescriptionActive: {
    color: 'rgba(255, 255, 255, 0.9)',
  },
  cardMetrics: {
    gap: 12,
  },
  metric: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  metricLabel: {
    fontSize: 12,
    fontFamily: 'Inter-SemiBold',
    color: '#6B7280',
    width: 60,
  },
  metricLabelActive: {
    color: 'rgba(255, 255, 255, 0.8)',
  },
  progressBar: {
    flex: 1,
    height: 6,
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    borderRadius: 3,
    overflow: 'hidden',
  },
  progressFill: {
    height: '100%',
    backgroundColor: '#00D4FF',
    borderRadius: 3,
  },
  progressFillActive: {
    backgroundColor: '#FFFFFF',
  },
  metricValue: {
    fontSize: 12,
    fontFamily: 'Inter-Bold',
    color: '#00D4FF',
    width: 35,
    textAlign: 'right',
  },
  metricValueActive: {
    color: '#FFFFFF',
  },
  infoSection: {
    marginTop: 20,
    marginBottom: 20,
    padding: 16,
    backgroundColor: 'rgba(0, 212, 255, 0.1)',
    borderRadius: 12,
    borderWidth: 1,
    borderColor: 'rgba(0, 212, 255, 0.3)',
  },
  infoHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
  },
  infoTitle: {
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
    color: '#FFFFFF',
    marginLeft: 8,
  },
  infoText: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#D1D5DB',
    lineHeight: 20,
  },
  bottomActions: {
    flexDirection: 'row',
    padding: 20,
    gap: 12,
  },
  actionButton: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 16,
    borderRadius: 12,
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    gap: 8,
  },
  actionButtonText: {
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
    color: '#FFFFFF',
  },
  primaryActionButton: {
    flex: 1,
    borderRadius: 12,
    overflow: 'hidden',
  },
  primaryActionGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 16,
    gap: 8,
  },
  primaryActionButtonText: {
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
    color: '#FFFFFF',
  },
});