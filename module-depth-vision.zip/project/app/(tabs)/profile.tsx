import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  SafeAreaView,
  Image,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { User, Settings, Camera, Download, Share, Trophy, Clock, Target, CreditCard as Edit3, Bell, Shield } from 'lucide-react-native';

interface StatCardProps {
  title: string;
  value: string;
  icon: React.ReactNode;
  trend?: string;
}

const StatCard: React.FC<StatCardProps> = ({ title, value, icon, trend }) => (
  <View style={styles.statCard}>
    <LinearGradient
      colors={['rgba(0, 212, 255, 0.1)', 'rgba(0, 212, 255, 0.05)']}
      style={styles.statGradient}
    >
      <View style={styles.statIcon}>
        {icon}
      </View>
      <Text style={styles.statValue}>{value}</Text>
      <Text style={styles.statTitle}>{title}</Text>
      {trend && (
        <Text style={styles.statTrend}>+{trend}</Text>
      )}
    </LinearGradient>
  </View>
);

interface MenuItemProps {
  title: string;
  subtitle?: string;
  icon: React.ReactNode;
  onPress: () => void;
  hasNotification?: boolean;
}

const MenuItem: React.FC<MenuItemProps> = ({
  title,
  subtitle,
  icon,
  onPress,
  hasNotification,
}) => (
  <TouchableOpacity style={styles.menuItem} onPress={onPress}>
    <View style={styles.menuIcon}>
      {icon}
    </View>
    <View style={styles.menuContent}>
      <Text style={styles.menuTitle}>{title}</Text>
      {subtitle && (
        <Text style={styles.menuSubtitle}>{subtitle}</Text>
      )}
    </View>
    {hasNotification && (
      <View style={styles.notificationDot} />
    )}
  </TouchableOpacity>
);

export default function ProfileScreen() {
  const [currentTime, setCurrentTime] = useState(new Date());

  React.useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  const formatTime = (date: Date) => {
    return date.toLocaleTimeString('en-US', {
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
    });
  };

  const formatDate = (date: Date) => {
    return date.toLocaleDateString('en-US', {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric',
    });
  };

  return (
    <View style={styles.container}>
      <LinearGradient
        colors={['#1F2937', '#111827']}
        style={styles.gradient}
      >
        <SafeAreaView style={styles.safeArea}>
          <ScrollView
            style={styles.scrollView}
            showsVerticalScrollIndicator={false}
          >
            {/* Header with Avatar */}
            <View style={styles.header}>
              <View style={styles.avatarContainer}>
                <LinearGradient
                  colors={['#00D4FF', '#0EA5E9']}
                  style={styles.avatarGradient}
                >
                  <Image
                    source={{ uri: 'https://images.pexels.com/photos/614810/pexels-photo-614810.jpeg' }}
                    style={styles.avatar}
                  />
                </LinearGradient>
                <TouchableOpacity style={styles.editAvatarButton}>
                  <Edit3 size={16} color="#FFFFFF" />
                </TouchableOpacity>
              </View>
              <Text style={styles.userName}>Alex Chen</Text>
              <Text style={styles.userTitle}>Depth Vision Specialist</Text>
            </View>

            {/* Time and Date Display */}
            <View style={styles.timeSection}>
              <View style={styles.timeCard}>
                <LinearGradient
                  colors={['rgba(0, 212, 255, 0.2)', 'rgba(0, 212, 255, 0.1)']}
                  style={styles.timeGradient}
                >
                  <Clock size={24} color="#00D4FF" />
                  <Text style={styles.timeText}>{formatTime(currentTime)}</Text>
                  <Text style={styles.dateText}>{formatDate(currentTime)}</Text>
                </LinearGradient>
              </View>
            </View>

            {/* Statistics */}
            <View style={styles.statsSection}>
              <Text style={styles.sectionTitle}>Statistics</Text>
              <View style={styles.statsGrid}>
                <StatCard
                  title="Scans Today"
                  value="24"
                  icon={<Camera size={20} color="#00D4FF" />}
                  trend="12%"
                />
                <StatCard
                  title="Accuracy"
                  value="94.2%"
                  icon={<Target size={20} color="#00D4FF" />}
                  trend="2.1%"
                />
                <StatCard
                  title="Total Scans"
                  value="1,247"
                  icon={<Trophy size={20} color="#00D4FF" />}
                />
                <StatCard
                  title="Hours Used"
                  value="89.3h"
                  icon={<Clock size={20} color="#00D4FF" />}
                />
              </View>
            </View>

            {/* Menu Items */}
            <View style={styles.menuSection}>
              <Text style={styles.sectionTitle}>Settings</Text>
              <View style={styles.menuContainer}>
                <MenuItem
                  title="App Settings"
                  subtitle="Preferences and configurations"
                  icon={<Settings size={20} color="#9CA3AF" />}
                  onPress={() => {}}
                />
                <MenuItem
                  title="Notifications"
                  subtitle="Manage alerts and updates"
                  icon={<Bell size={20} color="#9CA3AF" />}
                  onPress={() => {}}
                  hasNotification={true}
                />
                <MenuItem
                  title="Privacy & Security"
                  subtitle="Data protection settings"
                  icon={<Shield size={20} color="#9CA3AF" />}
                  onPress={() => {}}
                />
                <MenuItem
                  title="Export Data"
                  subtitle="Download your scan history"
                  icon={<Download size={20} color="#9CA3AF" />}
                  onPress={() => {}}
                />
                <MenuItem
                  title="Share App"
                  subtitle="Invite friends to use DepthVision"
                  icon={<Share size={20} color="#9CA3AF" />}
                  onPress={() => {}}
                />
              </View>
            </View>

            <View style={styles.bottomPadding} />
          </ScrollView>
        </SafeAreaView>
      </LinearGradient>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  gradient: {
    flex: 1,
  },
  safeArea: {
    flex: 1,
  },
  scrollView: {
    flex: 1,
  },
  header: {
    alignItems: 'center',
    padding: 20,
    paddingBottom: 30,
  },
  avatarContainer: {
    position: 'relative',
    marginBottom: 16,
  },
  avatarGradient: {
    width: 100,
    height: 100,
    borderRadius: 50,
    padding: 3,
  },
  avatar: {
    width: '100%',
    height: '100%',
    borderRadius: 50,
  },
  editAvatarButton: {
    position: 'absolute',
    bottom: 0,
    right: 0,
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: '#00D4FF',
    justifyContent: 'center',
    alignItems: 'center',
  },
  userName: {
    fontSize: 24,
    fontFamily: 'Inter-Bold',
    color: '#FFFFFF',
    marginBottom: 4,
  },
  userTitle: {
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    color: '#9CA3AF',
  },
  timeSection: {
    paddingHorizontal: 20,
    marginBottom: 30,
  },
  timeCard: {
    borderRadius: 16,
    overflow: 'hidden',
  },
  timeGradient: {
    padding: 20,
    alignItems: 'center',
  },
  timeText: {
    fontSize: 32,
    fontFamily: 'Inter-Bold',
    color: '#FFFFFF',
    marginTop: 12,
    marginBottom: 4,
  },
  dateText: {
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    color: '#9CA3AF',
  },
  statsSection: {
    paddingHorizontal: 20,
    marginBottom: 30,
  },
  sectionTitle: {
    fontSize: 20,
    fontFamily: 'Inter-Bold',
    color: '#FFFFFF',
    marginBottom: 16,
  },
  statsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
  },
  statCard: {
    flex: 1,
    minWidth: '45%',
    borderRadius: 12,
    overflow: 'hidden',
  },
  statGradient: {
    padding: 16,
    alignItems: 'center',
  },
  statIcon: {
    marginBottom: 8,
  },
  statValue: {
    fontSize: 20,
    fontFamily: 'Inter-Bold',
    color: '#FFFFFF',
    marginBottom: 4,
  },
  statTitle: {
    fontSize: 12,
    fontFamily: 'Inter-Regular',
    color: '#9CA3AF',
    textAlign: 'center',
  },
  statTrend: {
    fontSize: 10,
    fontFamily: 'Inter-SemiBold',
    color: '#10B981',
    marginTop: 4,
  },
  menuSection: {
    paddingHorizontal: 20,
  },
  menuContainer: {
    backgroundColor: 'rgba(255, 255, 255, 0.05)',
    borderRadius: 16,
    overflow: 'hidden',
  },
  menuItem: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 16,
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(255, 255, 255, 0.1)',
  },
  menuIcon: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
  },
  menuContent: {
    flex: 1,
  },
  menuTitle: {
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
    color: '#FFFFFF',
    marginBottom: 2,
  },
  menuSubtitle: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#9CA3AF',
  },
  notificationDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: '#FF6B6B',
  },
  bottomPadding: {
    height: 20,
  },
});