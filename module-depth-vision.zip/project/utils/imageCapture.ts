import { CameraView } from 'expo-camera';
import { Platform } from 'react-native';

export interface CapturedImage {
  uri: string;
  width: number;
  height: number;
  base64?: string;
}

export class ImageCaptureService {
  static async capturePhoto(cameraRef: React.RefObject<CameraView>): Promise<CapturedImage | null> {
    try {
      if (!cameraRef.current) {
        throw new Error('Camera reference not available');
      }

      const photo = await cameraRef.current.takePictureAsync({
        quality: 0.8,
        base64: true,
        skipProcessing: false,
      });

      if (!photo) {
        throw new Error('Failed to capture photo');
      }

      return {
        uri: photo.uri,
        width: photo.width || 0,
        height: photo.height || 0,
        base64: photo.base64
      };
    } catch (error) {
      console.error('Photo capture error:', error);
      return null;
    }
  }

  static async convertUriToBase64(uri: string): Promise<string> {
    try {
      if (Platform.OS === 'web') {
        const response = await fetch(uri);
        const blob = await response.blob();
        
        return new Promise((resolve, reject) => {
          const reader = new FileReader();
          reader.onloadend = () => {
            const base64String = (reader.result as string).split(',')[1];
            resolve(base64String);
          };
          reader.onerror = reject;
          reader.readAsDataURL(blob);
        });
      } else {
        // For native platforms, we can use the FileSystem API
        const { FileSystem } = require('expo-file-system');
        const base64 = await FileSystem.readAsStringAsync(uri, {
          encoding: FileSystem.EncodingType.Base64,
        });
        return base64;
      }
    } catch (error) {
      console.error('Base64 conversion error:', error);
      throw error;
    }
  }

  static validateImageFormat(uri: string): boolean {
    const supportedFormats = ['.jpg', '.jpeg', '.png', '.webp'];
    const lowerUri = uri.toLowerCase();
    return supportedFormats.some(format => lowerUri.includes(format));
  }
}