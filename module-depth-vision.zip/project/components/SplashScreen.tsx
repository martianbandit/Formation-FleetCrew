import React, { useEffect, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  Dimensions,
  TouchableOpacity,
  Image,
  ActivityIndicator,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import Animated, {
  useSharedValue,
  useAnimatedStyle,
  withTiming,
  withDelay,
  withSequence,
  Easing,
} from 'react-native-reanimated';

const { width: screenWidth, height: screenHeight } = Dimensions.get('window');

interface SplashScreenProps {
  onComplete: () => void;
}

export const SplashScreen: React.FC<SplashScreenProps> = ({ onComplete }) => {
  const [currentImageIndex, setCurrentImageIndex] = useState(0);
  const [showSpinner, setShowSpinner] = useState(false);
  const [showButton, setShowButton] = useState(false);
  const [loadingText, setLoadingText] = useState('Démarrage de l\'application...');

  // Animation values
  const logoScale = useSharedValue(0);
  const logoOpacity = useSharedValue(0);
  const titleTranslateY = useSharedValue(20);
  const titleOpacity = useSharedValue(0);
  const quoteOpacity = useSharedValue(0);
  const loadingOpacity = useSharedValue(0);
  const buttonOpacity = useSharedValue(0);
  const buttonScale = useSharedValue(0.8);

  // Background images
  const backgroundImages = [
    'https://cdn.leonardo.ai/users/dd5cf82f-db32-4a90-ad2d-ab6a6d6b20a5/generations/f9e9e992-9bc4-4cd1-84c1-f029bb359a0f/Leonardo_Vision_XL_Un_camion_Nord_americain_Style_futuriste_ef_3.jpg',
    'https://cdn.leonardo.ai/users/dd5cf82f-db32-4a90-ad2d-ab6a6d6b20a5/generations/1830c66c-7164-4c62-9bc0-fcf207c3b810/Leonardo_Vision_XL_Un_camion_Nord_americain_Style_futuriste_ef_0.jpg',
    'https://cdn.leonardo.ai/users/dd5cf82f-db32-4a90-ad2d-ab6a6d6b20a5/generations/74d1eda8-3699-4781-9c93-3503181c4c68/Leonardo_Vision_XL_Un_camion_Nord_americain_Style_futuriste_ef_2.jpg',
    'https://cdn.leonardo.ai/users/dd5cf82f-db32-4a90-ad2d-ab6a6d6b20a5/generations/74d1eda8-3699-4781-9c93-3503181c4c68/Leonardo_Vision_XL_Un_camion_Nord_americain_Style_futuriste_ef_3.jpg',
    'https://cdn.leonardo.ai/users/dd5cf82f-db32-4a90-ad2d-ab6a6d6b20a5/generations/48371333-e371-4d2f-8ddc-2b2cfbdbe2fc/Leonardo_Kino_XL_Un_camion_Nord_americain_Big_Rig_Style_futuri_1.jpg',
    'https://cdn.leonardo.ai/users/dd5cf82f-db32-4a90-ad2d-ab6a6d6b20a5/generations/0dd5f0df-be28-4f40-acf7-3803f81ecbe6/Leonardo_Kino_XL_Un_camion_Nord_americain_Big_Rig_Style_futuri_3.jpg',
    'https://cdn.leonardo.ai/users/dd5cf82f-db32-4a90-ad2d-ab6a6d6b20a5/generations/0dd5f0df-be28-4f40-acf7-3803f81ecbe6/Leonardo_Kino_XL_Un_camion_Nord_americain_Big_Rig_Style_futuri_0.jpg',
  ];

  useEffect(() => {
    // Start animations sequence
    logoScale.value = withTiming(1, { duration: 1000, easing: Easing.out(Easing.back(1.7)) });
    logoOpacity.value = withTiming(1, { duration: 800 });

    titleTranslateY.value = withDelay(500, withTiming(0, { duration: 800, easing: Easing.out(Easing.quad) }));
    titleOpacity.value = withDelay(500, withTiming(1, { duration: 800 }));

    quoteOpacity.value = withDelay(1000, withTiming(1, { duration: 1000 }));
    loadingOpacity.value = withDelay(1500, withTiming(1, { duration: 500 }));

    // Background image rotation
    const imageInterval = setInterval(() => {
      setCurrentImageIndex((prev) => (prev + 1) % backgroundImages.length);
    }, 6000);

    // Loading sequence
    const loadingTimeout = setTimeout(() => {
      setLoadingText('');
      loadingOpacity.value = withTiming(0, { duration: 300 });
      setShowSpinner(true);
      
      setTimeout(() => {
        setShowSpinner(false);
        setShowButton(true);
        buttonOpacity.value = withTiming(1, { duration: 500 });
        buttonScale.value = withTiming(1, { duration: 500, easing: Easing.out(Easing.back(1.7)) });
      }, 1500);
    }, 4000);

    return () => {
      clearInterval(imageInterval);
      clearTimeout(loadingTimeout);
    };
  }, []);

  // Animated styles
  const logoAnimatedStyle = useAnimatedStyle(() => ({
    transform: [{ scale: logoScale.value }],
    opacity: logoOpacity.value,
  }));

  const titleAnimatedStyle = useAnimatedStyle(() => ({
    transform: [{ translateY: titleTranslateY.value }],
    opacity: titleOpacity.value,
  }));

  const quoteAnimatedStyle = useAnimatedStyle(() => ({
    opacity: quoteOpacity.value,
  }));

  const loadingAnimatedStyle = useAnimatedStyle(() => ({
    opacity: loadingOpacity.value,
  }));

  const buttonAnimatedStyle = useAnimatedStyle(() => ({
    opacity: buttonOpacity.value,
    transform: [{ scale: buttonScale.value }],
  }));

  return (
    <View style={styles.container}>
      {/* Background Image */}
      <Image
        source={{ uri: backgroundImages[currentImageIndex] }}
        style={styles.backgroundImage}
        resizeMode="cover"
      />
      
      {/* Overlay */}
      <LinearGradient
        colors={['rgba(0,0,0,0.7)', 'rgba(0,0,0,0.5)', 'rgba(0,0,0,0.8)']}
        style={styles.overlay}
      />

      {/* Content */}
      <View style={styles.content}>
        {/* Logo */}
        <Animated.View style={[styles.logoContainer, logoAnimatedStyle]}>
          <Image
            source={{
              uri: 'https://raw.githubusercontent.com/martianbandit/FleetCrew-Agentics/refs/heads/main/Logo%20futuriste%20de%20camion%20n%C3%A9on.png'
            }}
            style={styles.logo}
            resizeMode="contain"
          />
        </Animated.View>

        {/* Company Name */}
        <Animated.View style={titleAnimatedStyle}>
          <Text style={styles.companyName}>
            Fleet<Text style={styles.crewText}>Crew</Text> AI
          </Text>
        </Animated.View>

        {/* Quote */}
        <Animated.View style={quoteAnimatedStyle}>
          <Text style={styles.quote}>
            "Après 23 ans dans les garages, j'ai réalisé qu'on perdait 60% de notre temps sur des conneries qui peuvent être automatisées. Mon IA ne remplace pas le mécanicien - elle le libère pour qu'il fasse ce qu'il fait de mieux : réparer des camions au lieu de chercher des pièces et remplir des formulaires."
          </Text>
        </Animated.View>

        {/* Loading Text */}
        {loadingText && (
          <Animated.Text style={[styles.loadingText, loadingAnimatedStyle]}>
            {loadingText}
          </Animated.Text>
        )}

        {/* Spinner */}
        {showSpinner && (
          <View style={styles.spinnerContainer}>
            <ActivityIndicator size="large" color="#00BCD4" />
          </View>
        )}

        {/* Start Button */}
        {showButton && (
          <Animated.View style={buttonAnimatedStyle}>
            <TouchableOpacity style={styles.startButton} onPress={onComplete}>
              <LinearGradient
                colors={['#00BCD4', '#0097A7']}
                style={styles.buttonGradient}
              >
                <Text style={styles.buttonText}>Commencer</Text>
              </LinearGradient>
            </TouchableOpacity>
          </Animated.View>
        )}
      </View>
    </View>
  );
};

// Export as default for easier importing
export const SplashScreenComponent = SplashScreen;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#1a202c',
  },
  backgroundImage: {
    position: 'absolute',
    width: screenWidth,
    height: screenHeight,
  },
  overlay: {
    position: 'absolute',
    width: screenWidth,
    height: screenHeight,
  },
  content: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 20,
  },
  logoContainer: {
    width: 180,
    height: 180,
    marginBottom: 30,
    borderRadius: 90,
    overflow: 'hidden',
    shadowColor: '#00BCD4',
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.5,
    shadowRadius: 20,
    elevation: 20,
  },
  logo: {
    width: '100%',
    height: '100%',
  },
  companyName: {
    fontFamily: 'Oswald-Bold',
    fontSize: 48,
    color: '#FFFFFF',
    textAlign: 'center',
    marginBottom: 20,
    textShadowColor: '#00BCD4',
    textShadowOffset: { width: 0, height: 0 },
    textShadowRadius: 15,
  },
  crewText: {
    color: '#00BCD4',
  },
  quote: {
    fontFamily: 'Inter-Regular',
    fontSize: 16,
    color: '#CBD5E0',
    textAlign: 'center',
    lineHeight: 24,
    maxWidth: 600,
    marginBottom: 40,
    textShadowColor: 'rgba(0,0,0,0.7)',
    textShadowOffset: { width: 1, height: 1 },
    textShadowRadius: 3,
  },
  loadingText: {
    fontFamily: 'Inter-Regular',
    fontSize: 18,
    color: '#A0AEC0',
    textAlign: 'center',
    marginTop: 20,
  },
  spinnerContainer: {
    marginTop: 30,
  },
  startButton: {
    marginTop: 40,
    borderRadius: 25,
    overflow: 'hidden',
    shadowColor: '#00BCD4',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 8,
  },
  buttonGradient: {
    paddingHorizontal: 40,
    paddingVertical: 15,
  },
  buttonText: {
    fontFamily: 'Inter-Bold',
    fontSize: 18,
    color: '#FFFFFF',
    textAlign: 'center',
  },
});