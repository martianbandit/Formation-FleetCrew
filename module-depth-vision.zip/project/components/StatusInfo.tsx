import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { BlurView } from 'expo-blur';
import { Zap, Cpu, Wifi } from 'lucide-react-native';

interface StatusInfoProps {
  currentMethod: string;
}

export const StatusInfo: React.FC<StatusInfoProps> = ({ currentMethod }) => {
  const [currentTime, setCurrentTime] = React.useState(new Date());

  React.useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  const formatTime = (date: Date) => {
    return date.toLocaleTimeString('en-US', {
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  const formatDate = (date: Date) => {
    return date.toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
    });
  };

  return (
    <View style={styles.container}>
      <BlurView intensity={20} style={styles.blurContainer}>
        <View style={styles.statusRow}>
          <View style={styles.timeSection}>
            <Text style={styles.timeText}>{formatTime(currentTime)}</Text>
            <Text style={styles.dateText}>{formatDate(currentTime)}</Text>
          </View>
          
          <View style={styles.methodSection}>
            <View style={styles.methodIndicator}>
              <Zap size={12} color="#00D4FF" />
              <Text style={styles.methodText}>{currentMethod}</Text>
            </View>
          </View>
          
          <View style={styles.statusIndicators}>
            <View style={styles.indicator}>
              <Cpu size={12} color="#10B981" />
              <Text style={styles.indicatorText}>98%</Text>
            </View>
            <View style={styles.indicator}>
              <Wifi size={12} color="#10B981" />
            </View>
          </View>
        </View>
      </BlurView>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    paddingHorizontal: 20,
    paddingTop: 10,
  },
  blurContainer: {
    borderRadius: 12,
    overflow: 'hidden',
  },
  statusRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingVertical: 12,
  },
  timeSection: {
    alignItems: 'flex-start',
  },
  timeText: {
    fontSize: 16,
    fontFamily: 'Inter-Bold',
    color: '#FFFFFF',
  },
  dateText: {
    fontSize: 12,
    fontFamily: 'Inter-Regular',
    color: '#9CA3AF',
  },
  methodSection: {
    flex: 1,
    alignItems: 'center',
  },
  methodIndicator: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(0, 212, 255, 0.2)',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 8,
    gap: 4,
  },
  methodText: {
    fontSize: 12,
    fontFamily: 'Inter-SemiBold',
    color: '#00D4FF',
  },
  statusIndicators: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  indicator: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  indicatorText: {
    fontSize: 10,
    fontFamily: 'Inter-Regular',
    color: '#10B981',
  },
});