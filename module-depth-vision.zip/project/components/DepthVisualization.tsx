import React from 'react';
import { View, StyleSheet } from 'react-native';
import Svg, { Rect } from 'react-native-svg';

interface DepthVisualizationProps {
  depthData: number[][];
}

export const DepthVisualization: React.FC<DepthVisualizationProps> = ({ depthData }) => {
  const getColorFromDepth = (depth: number): string => {
    // Create a heat map color from depth value (0-1)
    const hue = (1 - depth) * 240; // Blue to Red
    const saturation = 100;
    const lightness = 50 + depth * 30; // Vary lightness for better visibility
    return `hsl(${hue}, ${saturation}%, ${lightness}%)`;
  };

  if (!depthData || depthData.length === 0) return null;

  const rows = depthData.length;
  const cols = depthData[0]?.length || 0;
  const cellWidth = 300 / cols;
  const cellHeight = 400 / rows;

  return (
    <View style={styles.container}>
      <Svg width="100%" height="100%" viewBox="0 0 300 400">
        {depthData.map((row, i) =>
          row.map((depth, j) => (
            <Rect
              key={`${i}-${j}`}
              x={j * cellWidth}
              y={i * cellHeight}
              width={cellWidth}
              height={cellHeight}
              fill={getColorFromDepth(depth)}
              opacity={0.8}
            />
          ))
        )}
      </Svg>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
});